require('dotenv').config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const twilio = require("twilio");
const Razorpay = require("razorpay");

const app = express();
app.use(cors());
app.use(express.json());

// Twilio configuration
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const serviceSid = process.env.TWILIO_VERIFY_SERVICE_SID;

// Razorpay configuration
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

if (!accountSid || !authToken || !serviceSid) {
  throw new Error("❌ Twilio credentials missing! Check .env file.");
}

if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
  throw new Error("❌ Razorpay credentials missing! Check .env file.");
}

const twilioClient = twilio(accountSid, authToken);
const verifiedSessions = {};

// MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/inventory", {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("✅ Connected to MongoDB"))
.catch(err => console.error("❌ MongoDB connection error:", err));

// Product model
const Product = mongoose.model("Product", {
  code: String,
  name: String,
  price: Number,
  quantity: Number
});

// Seed sample products
async function seedProducts() {
  const count = await Product.countDocuments();
  if (count === 0) {
    await Product.create([
      { code: "123456", name: "Laptop", price: 50000, quantity: 10 },
      { code: "789012", name: "Phone", price: 25000, quantity: 15 }
    ]);
    console.log("✅ Sample products added");
  }
}
seedProducts();

// Middleware to check verification
const checkVerified = (req, res, next) => {
  const sessionToken = req.headers['authorization'];
  
  if (!sessionToken || !verifiedSessions[sessionToken]) {
    return res.status(403).json({ error: "OTP verification required" });
  }
  
  next();
};

// OTP endpoints
app.post("/send-otp", async (req, res) => {
  const { phoneNumber } = req.body;
  
  if (!phoneNumber || !phoneNumber.startsWith("+")) {
    return res.status(400).json({ error: "Invalid phone number format. Use +CountryCode..." });
  }

  try {
    const verification = await twilioClient.verify.v2.services(serviceSid)
      .verifications
      .create({ to: phoneNumber, channel: 'sms' });
      
    res.json({ success: true, message: "OTP sent successfully" });
  } catch (error) {
    console.error("OTP send error:", error);
    res.status(500).json({ error: "Failed to send OTP" });
  }
});

app.post("/verify-otp", async (req, res) => {
  const { phoneNumber, code } = req.body;
  
  try {
    const verificationCheck = await twilioClient.verify.v2.services(serviceSid)
      .verificationChecks
      .create({ to: phoneNumber, code: code });
      
    if (verificationCheck.status === 'approved') {
      const sessionToken = Math.random().toString(36).substring(2) + Date.now().toString(36);
      verifiedSessions[sessionToken] = {
        phoneNumber,
        verifiedAt: new Date()
      };
      
      res.json({ 
        success: true, 
        verified: true,
        sessionToken 
      });
    } else {
      res.json({ success: false, verified: false });
    }
  } catch (error) {
    console.error("OTP verification error:", error);
    res.status(500).json({ error: "OTP verification failed" });
  }
});

// Product endpoint
app.get("/product/:code", checkVerified, async (req, res) => {
  try {
    const product = await Product.findOne({ code: req.params.code });
    if (!product) return res.status(404).json({ error: "Product not found" });
    res.json(product);
  } catch (error) {
    console.error("Product fetch error:", error);
    res.status(500).json({ error: "Failed to fetch product" });
  }
});

// Razorpay endpoint
app.post("/create-razorpay-order", checkVerified, async (req, res) => {
  try {
    const { amount } = req.body;
    
    if (!amount || isNaN(amount)) {
      return res.status(400).json({ error: "Invalid amount" });
    }

    const options = {
      amount: amount, // amount in paise
      currency: "INR",
      receipt: "order_" + Date.now(),
      payment_capture: 1
    };

    const order = await razorpay.orders.create(options);
    res.json(order);
  } catch (error) {
    console.error("Razorpay error:", error);
    res.status(500).json({ error: error.message || "Payment processing failed" });
  }
});

// Start server
app.listen(5000, () => console.log("✅ Server running on port 5000"));