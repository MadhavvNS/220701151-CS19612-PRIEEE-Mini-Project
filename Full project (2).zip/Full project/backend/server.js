// server.js

require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const twilio = require('twilio');
const Razorpay = require('razorpay');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../frontend'))); // Serve frontend files

// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/inventory', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ Connected to MongoDB'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// Mongoose Model
const Product = mongoose.model("Product", {
  code: String,
  name: String,
  price: Number,
  quantity: Number
});

// Twilio client setup
const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);


// Razorpay instance setup
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// ======================== ROUTES ========================

// ---------- Inventory APIs ----------
app.get("/product/:code", async (req, res) => {
  try {
    const product = await Product.findOne({ code: req.params.code });
    if (!product) return res.status(404).json({ error: "Product not found" });
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

app.post("/checkout", async (req, res) => {
  const cart = req.body.cart;

  try {
    for (const item of cart) {
      const product = await Product.findOne({ code: item.code });

      if (!product) return res.status(404).json({ error: `Product ${item.name} not found` });

      if (product.quantity < item.quantity) {
        return res.status(400).json({ error: `Insufficient stock for ${item.name}` });
      }

      product.quantity -= item.quantity;
      await product.save();
    }
    res.json({ message: "Checkout successful" });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

// ---------- OTP APIs ----------
let otpStore = {};

app.post('/send-otp', async (req, res) => {
  const { phone } = req.body;
  const otp = Math.floor(100000 + Math.random() * 900000);

  try {
    await client.messages.create({
      body: `Your OTP is ${otp}`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phone
    });

    otpStore[phone] = otp;
    res.json({ message: 'OTP sent successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Failed to send OTP' });
  }
});

app.post('/verify-otp', (req, res) => {
  const { phone, otp } = req.body;
  
  if (otpStore[phone] && otpStore[phone] == otp) {
    delete otpStore[phone];
    res.json({ message: 'OTP verified successfully' });
  } else {
    res.status(400).json({ message: 'Invalid OTP' });
  }
});

// ---------- Razorpay APIs ----------
app.post('/create-order', async (req, res) => {
  try {
    const { amount } = req.body;
    const order = await razorpay.orders.create({
      amount: amount, // in paise
      currency: "INR",
      receipt: `receipt_order_${Math.random() * 1000}`
    });
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create order" });
  }
});

// ======================== START SERVER ========================
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
